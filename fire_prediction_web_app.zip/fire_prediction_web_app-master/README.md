This web app makes a prediction of if there is a high probability of a fire outbreak or not based on a deep
learning model which was developed with Keras and integrated into a flsk framework to make a web app

Technologies Used:

Keras
Theano
Flask
Python
Bootstrap
Html

To run, download folder, install keras and tensorflow from the pip or conda repository in a virtual environment,
install flask in the same environment. Open up the folder in that environment and run.

PS: You may have to change the configuration of your Keras backend to theano.

GoodLuck!

